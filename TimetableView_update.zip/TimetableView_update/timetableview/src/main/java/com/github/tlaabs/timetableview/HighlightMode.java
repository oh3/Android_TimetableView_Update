package com.github.tlaabs.timetableview;

public enum HighlightMode {
    COLOR,
    IMAGE
}
